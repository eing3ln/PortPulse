<?php
// Include config file
require_once "connectdB-crudDevice.php";
 
// Define variables and initialize with empty values
$Lnum = $remarks = "";
$Lnum_err = $remarks_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate Luggage ID Number
    $input_Lnum = trim($_POST["Lnum"]);
    if(empty($input_Lnum)) {
        $Lnum_err = "Please enter your Luggage ID Number.";
    } else {
        // Check if the Luggage ID Number is in the format N-XXXXX
        if (preg_match("/^[A-Za-z]-\d{5}$/", $input_Lnum)) {
            $Lnum = $input_Lnum;
        } else {
            $Lnum_err = "Please enter a valid Luggage ID Number in the format N-XXXXX.";
        }
    }

    // Validate Remarks
    $input_remarks = trim($_POST["remarks"]);
    if(empty($input_remarks)) {
        $remarks_err = "Please enter Target Destination Address.";
    } elseif(!filter_var($input_remarks, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))) {
        $remarks_err = "Please enter a valid data.";
    } else {
        $remarks = $input_remarks;
    }
    
    // Check input errors before inserting in database
    if(empty($Lnum_err) && empty($remarks_err)) {
        // Prepare an insert statement
        $sql = "INSERT INTO device (Lnum, remarks, ID) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "isi", $param_Lnum, $param_remarks, $param_ID);
            
            // Set parameters
            $param_Lnum = $Lnum;
            $param_remarks = $remarks;
            $param_ID = $ID;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: crud-index.php");
                exit();
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>PortPulse</title>
  <link rel="icon" type="image/x-icon" href="logo.png">

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>

<body>

<!-- Navbar (sit on top) -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand w3-wide"><b>PortPulse</b></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

    <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link w3-button" href="home.html">Home</a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">Customer</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="customer/create.php">Add Customer</a></li>
              <li><a class="dropdown-item" href="customer/crud-index.php">Customer Reports</a></li>
            </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">Device</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="create.php">Add Device</a></li>
              <li><a class="dropdown-item" href="crud-index.php">Device Reports</a></li>
            </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">Luggage</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="luggage/create.php">Add Luggage</a></li>
              <li><a class="dropdown-item" href="luggage/crud-index.php">Customer Luggage Report</a></li>
            </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">Admin Profile</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="profile/update.php">Update Profile</a></li>
              <li><a class="dropdown-item" href="index.html">Sign out</a></li>
            </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Create Operation for Device -->
<header class="w3-container w3-teal w3-center" style="padding:26px 16px">
  <h1 class="w3-margin w3-jumbo">ADD DEVICE PAGE</h1>
</header>

<div class="w3-row-padding w3-padding-36 w3-container">
    <div class="dashboard">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Add Device</h2>
                    <p>Kindly fill out the required information.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                        <div class="form-group">
                            <label>Luggage ID Number</label>
                            <input type="text" name="Lnum" class="form-control <?php echo (!empty($fLnum_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Lnum; ?>">
                            <span class="invalid-feedback"><?php echo $Lnum_err;?></span>
                        </div>
        
                        <div class="form-group">
                            <label>Remarks</label>
                            <input type="text" name="remarks" class="form-control <?php echo (!empty($remarks_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $remarks; ?>">
                            <span class="invalid-feedback"><?php echo $remarks_err;?></span>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="crud-index.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div><br><br>

<!-- Footer -->
<footer class="footer">
    <h4 class="footer-dev">Developed by: <h4 class="footer-name">Naguit | Isidro | Opena | Fisalbon | Camus | Aquino</h4></h4>
</footer>

</div>

</body>
</html>